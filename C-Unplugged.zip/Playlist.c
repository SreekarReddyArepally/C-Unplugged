#include"stdio.h"
#include"Playlist.h"
#include<stdlib.h>
#include<string.h>

Playnode *current=NULL;

Playnode *FindPlaylistTail(Playnode *head) {
    if (head == NULL) return NULL;
    return head->prev;
}

void WritePlay(const char *filename,Playnode **head){
    FILE *playptr;
    playptr=fopen(filename,"w");
    if (!playptr) return; // Only check if file opened

    if (*head == NULL) {
        fclose(playptr);
        return;
    }
    
    Playnode *temp=*head;
    do { // Use do-while for a circular list to ensure head is written
        fprintf(playptr,"%s\t%s\n",temp->newsong->name,temp->newsong->artist);
        temp=temp->next;
    } while(temp!=*head); // Correct termination condition

    fclose(playptr);
    printf("Playlist file updated successfully.\n");
    return;
}

void ViewPlaylist(Playnode **head){
    int idx=1;
    if(*head==NULL){
        printf("Playlist is empty.\nTry adding something.\n");
        return;
    }
    Playnode *temp=*head;
    
    printf("\n--- C-Unplugged Playlist ---\n");
    printf("ID   Name                                        Artist\n");
    do {
        printf("%2d   %-43s %s\n",idx++,temp->newsong->name,temp->newsong->artist);
        temp=temp->next;
    } while(temp!=*head);
    printf("----------------------------\n");
    return;
}

void AddsongtoPlaylist(Playnode **head,Playnode *newnode){
    if (*head == NULL) {
        *head = newnode;
        newnode->next = newnode;
        newnode->prev = newnode;
    } else {
        Playnode *tail = (*head)->prev; 
        
        newnode->next = *head;
        newnode->prev = tail;
        
        tail->next = newnode;
        (*head)->prev = newnode;
    }
    WritePlay("Playlist.txt", head);
    return;
}

void RemsongfromPlaylist(Playnode **head,Playnode *target){
    if (*head == NULL || target == NULL) return;

    if (*head == target && target->next == *head) {
        /*if only one nde*/
        *head = NULL;
    } else {
        Playnode *prevnode=target->prev;
        Playnode *nextnode=target->next;
        
        // Relink surrounding nodes
        prevnode->next=nextnode;
        nextnode->prev=prevnode;
        
        // If the head was the target, update head
        if(target==*head){
            *head=nextnode;
        }
    }
    // The song data was malloc'd inside main2.c or Addalbtoplaylist
    if (target->newsong) free(target->newsong);
    free(target);
    printf("Removed successfully.\n");
    WritePlay("Playlist.txt", head);
    return;
}

void Addalbtoplaylist(Playnode **head, Album *newalb){ // Renamed 'new' to 'newalb'
    Song *song_curr = newalb->songhead;
    if (song_curr == NULL) {
        printf("Album '%s' is empty. Nothing to add.\n", newalb->name);
        return;
    }

    Playnode *firstnew = NULL;
    Playnode *lastnew = NULL;
    Playnode *prevnew = NULL;

    while (song_curr != NULL) {
        Playnode *newnode = (Playnode*)malloc(sizeof(Playnode));
        if (!newnode) { /* Allocation failed */ return; }
        
        newnode->newsong = (Song*)malloc(sizeof(Song));
        if (!newnode->newsong) { free(newnode); return; }
        // Copy song data
        memcpy(newnode->newsong, song_curr, sizeof(Song));

        newnode->prev = prevnew;
        newnode->next = NULL;

        if (firstnew == NULL) {
            firstnew = newnode;
        }
        if (prevnew != NULL) {
            prevnew->next = newnode;
        }
        
        prevnew = newnode;
        lastnew = newnode;
        song_curr = song_curr->next;
    }

    if (*head == NULL) {
        // If playlist is empty, the sequence becomes the list
        *head = firstnew;
        lastnew->next = *head;
        (*head)->prev = lastnew;
    } else {
        Playnode *tail = (*head)->prev;

        // Link the end of the existing list to the start of the new sequence
        tail->next = firstnew;
        firstnew->prev = tail;

        // Link the end of the new sequence back to the head
        lastnew->next = *head;
        (*head)->prev = lastnew;
    }
    
    printf("Album '%s' added to playlist.\n", newalb->name);
    WritePlay("Playlist.txt", head);
}

void Remalbfromplaylist(Playnode **head, Album *targetalb){
    if (*head == NULL || targetalb->songhead == NULL) {
        printf("Playlist is empty or Album is empty.\n");
        return;
    }

    Song *album_song_curr = targetalb->songhead;
    Playnode *playlist_curr = *head;
    int found_start = 0;
    
    // 1. Find the start of the album sequence in the playlist
    Playnode *check_temp = *head;
    do { // Fix: Must use do-while to check head node
        if (strcmp(check_temp->newsong->name, album_song_curr->name) == 0 &&
            strcmp(check_temp->newsong->artist, album_song_curr->artist) == 0) {
            found_start = 1;
            playlist_curr = check_temp;
            break;
        }
        check_temp = check_temp->next;
    } while (check_temp != *head);
    
    if (!found_start) {
        printf("Album '%s' not found in playlist sequence.\n", targetalb->name);
        return;
    }
    
    Playnode *startnode = playlist_curr;
    Playnode *end_node = NULL;
    
    // 2. Verify the full continuous sequence
    Playnode *verify_curr = startnode;
    Song *verify_alb_song = targetalb->songhead;
    
    while (verify_alb_song != NULL) {
        // Check if we looped back, preventing infinite loop if the album is not fully contained
        if (verify_curr == startnode && end_node != NULL) { 
            printf("Error: Found start but sequence wrapped or was incomplete.\n");
            return;
        }

        if (strcmp(verify_curr->newsong->name, verify_alb_song->name) == 0 &&
            strcmp(verify_curr->newsong->artist, verify_alb_song->artist) == 0) {
            
            end_node = verify_curr;
            verify_curr = verify_curr->next;
            verify_alb_song = verify_alb_song->next;
        } else {
            printf("Album sequence broke at song '%s' in the playlist. Aborting removal.\n", verify_alb_song->name);
            return;
        }
    }

    // 3. Remove the identified sequence (startnode to end_node)
    
    Playnode *preno = startnode->prev;
    Playnode *nexno = end_node->next;

    // A. Handle case: only one node, or the list becomes empty
    if (startnode == *head && end_node == preno) { // The entire list is the album
        *head = NULL;
    } else {
        // B. Relink the nodes surrounding the sequence
        preno->next = nexno;
        nexno->prev = preno;

        // C. Update head if the removed sequence started at head
        if (startnode == *head) {
            *head = nexno;
        }
    }

    // 4. Free the nodes in the sequence
    Playnode *tem = startnode;
    Playnode *next_free;
    while (1) {
        next_free = tem->next;
        
        free(tem->newsong); 
        free(tem);

        if (tem == end_node) break; // Stop after freeing the end node
        tem = next_free;
    }

    printf("Removed album '%s' from playlist successfully.\n", targetalb->name);
    WritePlay("Playlist.txt", head);
    return;
}