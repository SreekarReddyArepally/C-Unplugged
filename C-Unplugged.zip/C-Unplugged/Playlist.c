#include"stdio.h"
#include"Playlist.h"
#include<stdlib.h>
#include<string.h>

Playnode *current=NULL;

Playnode *FindPlaylistTail(Playnode *head) {
    if (head == NULL) return NULL;
    return head->prev;
}

void WritePlay(const char *filename,Playnode **head){
    FILE *playptr;
    playptr=fopen(filename,"w");
    if (!playptr) return;

    if (*head == NULL) {
        fclose(playptr);
        return;
    }
    
    Playnode *temp=*head;
    do{
        fprintf(playptr,"%s\t%s\n",temp->newsong->name,temp->newsong->artist);
        temp=temp->next;
    } while(temp!=*head);

    fclose(playptr);
    printf("Playlist file updated successfully.\n");
    return;
}

void ViewPlaylist(Playnode **head){
    int idx=1;
    if(*head==NULL){
        printf("Playlist is empty.\nTry adding something.\n");
        return;
    }
    Playnode *temp=*head;
    
    printf("\n--- C-Unplugged Playlist ---\n");
    printf("ID   Name                                        Artist\n");
    do {
        printf("%2d   %-43s %s\n",idx++,temp->newsong->name,temp->newsong->artist);
        temp=temp->next;
    } while(temp!=*head);
    printf("----------------------------\n");
    return;
}

void AddsongtoPlaylist(Playnode **head,Playnode *newnode){
    if (*head == NULL) {
        *head = newnode;
        newnode->next = newnode;
        newnode->prev = newnode;
    } else {
        Playnode *tail = (*head)->prev; 
        
        newnode->next = *head;
        newnode->prev = tail;
        
        tail->next = newnode;
        (*head)->prev = newnode;
    }
    WritePlay("Playlist.txt", head);
    return;
}

void RemsongfromPlaylist(Playnode **head,Playnode *target){
    if (*head == NULL || target == NULL) return;

    if (*head == target && target->next == *head) {
        /*if only one nde*/
        *head = NULL;
    } else {
        Playnode *prevnode=target->prev;
        Playnode *nextnode=target->next;
        prevnode->next=nextnode;
        nextnode->prev=prevnode;
        if(target==*head){
            *head=nextnode;
        }
    }
    if (target->newsong) free(target->newsong);
    free(target);
    printf("Removed successfully.\n");
    WritePlay("Playlist.txt", head);
    return;
}

void Addalbtoplaylist(Playnode **head, Album *newalb){
    Song *curso = newalb->songhead;
    if (curso == NULL) {
        printf("Album '%s' is empty. Nothing to add.\n", newalb->name);
        return;
    }
    Playnode *firstnew = NULL;
    Playnode *lastnew = NULL;
    Playnode *prevnew = NULL;
    while (curso != NULL) {
        Playnode *newnode = (Playnode*)malloc(sizeof(Playnode));
        if (!newnode)
            return;
        newnode->newsong = (Song*)malloc(sizeof(Song));
        if (!newnode->newsong) { free(newnode); return; }
        memcpy(newnode->newsong, curso, sizeof(Song));
        newnode->prev = prevnew;
        newnode->next = NULL;
        if(firstnew==NULL)
            firstnew=newnode;
        if(prevnew!=NULL)
            prevnew->next=newnode;
        prevnew = newnode;
        lastnew = newnode;
        curso = curso->next;
    }

    if (*head == NULL) {
        *head = firstnew;
        lastnew->next = *head;
        (*head)->prev = lastnew;
    } else {
        Playnode *tail = (*head)->prev;

        tail->next = firstnew;
        firstnew->prev = tail;

        lastnew->next = *head;
        (*head)->prev = lastnew;
    }
    
    printf("Album '%s' added to playlist.\n", newalb->name);
    WritePlay("Playlist.txt", head);
}

void Remalbfromplaylist(Playnode **head, Album *targetalb){
    if (*head == NULL || targetalb->songhead == NULL) {
        printf("Playlist is empty or Album is empty.\n");
        return;
    }

    Song *album_curso = targetalb->songhead;
    Playnode *curply = *head;
    int srt = 0;
    
    Playnode *tmp = *head;
    do{
        if (strcmp(tmp->newsong->name, album_curso->name) == 0 &&
            strcmp(tmp->newsong->artist, album_curso->artist) == 0) {
            srt = 1;
            curply = tmp;
            break;
        }
        tmp = tmp->next;
    } while (tmp != *head);
    
    if (!srt) {
        printf("Album '%s' not found in playlist sequence.\n", targetalb->name);
        return;
    }
    
    Playnode *startnode = curply;
    Playnode *endon = NULL;
    
    Playnode *vercur = startnode;
    Song *veralso = targetalb->songhead;
    
    while (veralso != NULL) {
        if (vercur == startnode && endon != NULL) { 
            printf("Error: Found start but sequence wrapped or was incomplete.\n");
            return;
        }

        if (strcmp(vercur->newsong->name, veralso->name) == 0 &&
            strcmp(vercur->newsong->artist, veralso->artist) == 0) {
            
            endon = vercur;
            vercur = vercur->next;
            veralso = veralso->next;
        } else {
            printf("Album sequence broke at song '%s' in the playlist. Aborting removal.\n", veralso->name);
            return;
        }
    }

    
    Playnode *preno = startnode->prev;
    Playnode *nexno = endon->next;

    if (startnode == *head && endon == preno) 
        *head = NULL;
    else {
        preno->next = nexno;
        nexno->prev = preno;

        if (startnode == *head) {
            *head = nexno;
        }
    }

    Playnode *tem = startnode;
    Playnode *next_free;
    while (1) {
        next_free = tem->next;
        
        free(tem->newsong); 
        free(tem);

        if (tem == endon) break;
        tem = next_free;
    }

    printf("Removed album '%s' from playlist successfully.\n", targetalb->name);
    WritePlay("Playlist.txt", head);
    return;
}