#include "Songs.h"   
#include "Album.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

extern int ALBUMID;

void GenAlbName(Album *album) {
    if (!album) return;
    snprintf(album->albfilename, sizeof(album->albfilename), "Album%d.txt", album->id);
}

Album *GetAlbID(Album *head,int idx){
    Album *temp=head;
    int cnt=1;
    while(temp!=NULL){
        if(cnt==idx){
            return temp;
        }
        temp=temp->next;
        cnt++;
    }
    return NULL;
}

void RewriteAlbSongs(const char *filename,Song **target){
    if (!filename) return;
    FILE *albptr=fopen(filename,"w");
    if (!albptr) {
        perror("Couldn't open album songs file for writing");
        return;
    }
    int idx=1;
    Song *temp=*target;
    while(temp!=NULL){
        /* now Song is a complete type so its fields are accessible */
        fprintf(albptr,"%d %s\t%s\n",idx++,temp->name,temp->artist);
        temp=temp->next;
    }
    fclose(albptr);
}

void RewriteAlb(Album **head){
    if (!head) return;
    FILE *albptr=fopen("Albums.txt","w");
    if (!albptr) {
        perror("Couldn't open Albums.txt for writing");
        return;
    }

    Album *temp=*head;
    while(temp!=NULL){
        fprintf(albptr,"%d\t%s\t%d\t%s\n", temp->id, temp->name, temp->songnum, temp->albfilename);
        temp=temp->next;
    }
    fclose(albptr);
}

void InsertAlbumLL(const char *filename,Album **head){
    if (!filename || !head) return;
    FILE *songptr=fopen(filename,"r");
    if (!songptr) return;
    char temp[201]="";
    while(fgets(temp,201,songptr)!=NULL){
        Album *newalbum=malloc(sizeof(Album));
        if (!newalbum) break;
        newalbum->next=NULL;
        newalbum->songhead=NULL;
        if (sscanf(temp, "%d\t%[^\t]\t%d\t%[^\r\n]",
                   &newalbum->id,
                   newalbum->name,
                   &newalbum->songnum,
                   newalbum->albfilename) != 4){
            free(newalbum);
            continue;
        }
        if (newalbum->id >= ALBUMID) {
             ALBUMID = newalbum->id + 1;
        }

        if(*head==NULL){
            *head=newalbum;
        }
        else{
            Album *t=*head;
            while(t->next!=NULL){
                t=t->next;
            }
            t->next=newalbum;
        }
    }
    fclose(songptr);
}

void AddAlbum(Album **head,Album *newalbum){
    if (!head || !newalbum) return;

    newalbum->next=NULL;
    newalbum->id=ALBUMID++;
    GenAlbName(newalbum);
    newalbum->songnum=0;
    newalbum->songhead=NULL;

    if(*head==NULL){
        *head=newalbum;
    }
    else{
        Album *tempsong=*head;
        while(tempsong->next!=NULL){
            tempsong=tempsong->next;
        }
        tempsong->next=newalbum;
    }

    /* create album file (empty) */
    FILE *f = fopen(newalbum->albfilename,"w");
    if (f) fclose(f);

    RewriteAlb(head);
    return;
}

void RemoveAlbum(Album **head,Album *remalb){
    if (!head || !*head || !remalb) return;
    Album *prev=*head;
    if(*head==remalb){       /*if first alb itself is the removed alb*/
        *head=remalb->next;
    }
    else{
        while(prev!=NULL && prev->next!=remalb){   /*move till find or NULL*/
            prev=prev->next;
        }
        if(prev!=NULL){ /*remalb exists and we remove it*/
            prev->next=remalb->next;
        }
        else{
            return;
        }
    }

    /* free songs inside album */
    Song *cursong = remalb->songhead;
    while(cursong != NULL) {
        Song *next_song = cursong->next;
        free(cursong);
        cursong = next_song;
    }

    /* remove album file if exists (ignore errors) */
    remove(remalb->albfilename);

    RewriteAlb(head);
    free(remalb);
    return;
}

/* NOTE: header declares Addsongtoalbum (lowercase 'a') */
void Addsongtoalbum(Album *target,Song *new){
    if (!target || !new) return;
    Song *tmp=target->songhead;
    new->next=NULL;
    if(tmp==NULL){
        target->songhead=new;
    }
    else{
        while(tmp->next!=NULL){
            tmp=tmp->next;
        }
        tmp->next=new;
    }
    target->songnum++;
    RewriteAlbSongs(target->albfilename,&(target->songhead));
}

void RemsongfromAlbum(Album *target,Song *new){
    if (!target || !new) return;
    Song *tmp=target->songhead;
    if(target->songhead==new){  /*if we need to rem the first song of the album*/
        target->songhead=new->next;
    }
    else{
        while(tmp!=NULL && tmp->next!=new){
            tmp=tmp->next;
        }
        if(tmp!=NULL){
            tmp->next=new->next;
        }
        else{
            printf("Song doesn't exist.\n");
            return;
        }
    }
    free(new);
    target->songnum-=1;
    RewriteAlbSongs(target->albfilename,&(target->songhead));
    return;
}

void ViewSongsinAlbum(Album *target){
    if (!target) return;
    int idx=1;
    Song *tmp=target->songhead;
    if(target->songhead==NULL){
        printf("Album is Empty.\n");
        return;
    }
    printf("Songs in %s\n",target->name);
    printf("=============================================================================\n");
    printf("ID   Name                                        Artist\n");
    while(tmp!=NULL){
        printf("%d   %-43s %s\n",idx++,tmp->name,tmp->artist);
        tmp=tmp->next;
    }
    printf("=============================================================================\n");
    return;
}
