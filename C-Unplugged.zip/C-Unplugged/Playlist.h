#ifndef PLAYLIST_H
#define PLAYLIST_H

#include <stdio.h>
#include "Songs.h"
#include "Album.h"

typedef struct Playnode {
    Song *newsong;
    struct Playnode *next;
    struct Playnode *prev;
} Playnode;

void WritePlay(const char *filename, Playnode **head);
void ViewPlaylist(Playnode **head);
void AddsongtoPlaylist(Playnode **head, Playnode *newnode);
void RemsongfromPlaylist(Playnode **head, Playnode *target);
void Addalbtoplaylist(Playnode **head, Album *newalb);
void Remalbfromplaylist(Playnode **head, Album *targetalb);

#endif
