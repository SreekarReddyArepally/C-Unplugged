#ifndef SONGS_H
#define SONGS_H

#include <stdio.h>

typedef struct Album Album;

extern int SONGID;

typedef struct Song {
    int id;
    char name[101];
    char artist[101];
    struct Song *next;
} Song;

/* prototypes */
Song *GetSongID(Song *head,int idx);
Song *FindSongAlb(Album *target,int idx);
Song *Find(Song *head,Song *remsong);

void insert(const char *filename,Song **head);
void AddSong(Song **head,Song *newsong);
void RemoveSong(Song **head,Song *remsong);
void ViewSongs(Song **head);
void RewriteFile(Song **head);

#endif
