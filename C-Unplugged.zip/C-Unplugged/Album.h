#ifndef ALBUM_H
#define ALBUM_H

#include <stdio.h>

typedef struct Song Song;

typedef struct Album {
    int id;
    char name[101];
    int songnum;
    Song *songhead;
    struct Album *next;
    char albfilename[101];
} Album;

extern int ALBUMID;

void GenAlbName(Album *album);
Album *GetAlbID(Album *head,int idx);
void InsertAlbumLL(const char *filename,Album **head);
void ViewAlbums(Album **head);
void AddAlbum(Album **head,Album *newsong);
void RemoveAlbum(Album **head,Album *remalb);

void Addsongtoalbum(Album *target, Song *new);
void RemsongfromAlbum(Album *target, Song *new);
void ViewSongsinAlbum(Album *target);
void RewriteAlb(Album **head);
void RewriteAlbSongs(const char *filename, Song **target);

#endif
