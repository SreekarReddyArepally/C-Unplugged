#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "Songs.h"
#include "Album.h"
#include "Playlist.h"

Song *songlib=NULL;
Album *albumnode=NULL;
Playnode *playlisthead=NULL;
int SONGID=1;
int ALBUMID=1;

void userlog(FILE *userinp, const char *command) {
    time_t timer;
    char buffer[26];
    struct tm* tminf;
    time(&timer);
    tminf = localtime(&timer);
    strftime(buffer, 26, "[%Y-%m-%d %H:%M:%S] ", tminf);
    if (userinp) fprintf(userinp, "%s%s\n", buffer, command);
}

int logvalue(FILE *userinp) {
    int value;
    if (scanf(" %d", &value) != 1) {
        while(getchar()!='\n');
        if (userinp) userlog(userinp, "ERROR: Invalid input attempt.");
        return -1;
    }
    while(getchar()!='\n');

    if (userinp) {
        char logbuf[32];
        sprintf(logbuf, "%d", value);
        userlog(userinp, logbuf);
    }

    return value;
}

int main(){
    /*inserting stuff into LL*/
    insert("Songs.txt",&songlib);
    InsertAlbumLL("Albums.txt",&albumnode);

    while(1){
        printf("\n==========C-Unplugged==========\nMAIN MENU\n1.Songs\n2.Albums\n3.Playlist\n4.User Log\n5.Exit\n");
        printf("===============================\n");

        FILE *userinp = fopen("User_History.txt","a");
        if (!userinp) {
            printf("Warning: couldn't open user history file for logging.\n");
        }

        printf("Type the ID of the Menu:");

        int ID = logvalue(userinp);
        if (ID == -1) {
            if (userinp) fclose(userinp);
            continue;
        }

        if (userinp) fclose(userinp);

/*SongLib*/ if(ID==1){
                while(1){
                    printf("=====Songs Menu=====\n");
                    printf("1.View Songs\n2.Add\n3.Remove\n4.Back\n");
                    printf("====================\n");
                    printf("Where in the Songs Menu? :");
                    int sid;
                    if(scanf("%d",&sid)!=1){
                        while(getchar()!='\n');
                        printf("Error, try Again.\n");
                        continue;
                    }
                    while(getchar()!='\n');
/*view songs*/      if(sid==1){
                        ViewSongs(&songlib);
                    }
/*add songs*/       if(sid==2){
                        Song *new = malloc(sizeof(Song));
                        if (!new) { printf("Memory allocation failed.\n"); continue; }
                        memset(new,0,sizeof(Song));
                        printf("Song Name:");
                        if (fgets(new->name,101,stdin) == NULL) { free(new); continue; }
                        new->name[strcspn(new->name,"\n")] = '\0';
                        printf("Artist Name:");
                        if (fgets(new->artist,101,stdin) == NULL) { free(new); continue; }
                        new->artist[strcspn(new->artist,"\n")] = '\0';

                        Song *new1 = Find(songlib,new);
                        if(new1==NULL){
                            new->id = SONGID++;
                            printf("Song Added.\n");
                            AddSong(&songlib,new);
                        }
                        else{
                            printf("Song already exists.\n");
                            free(new);
                        }
                    }
/*rem songs*/       if(sid==3){
                        Song remtmp;
                        memset(&remtmp,0,sizeof(remtmp));
                        printf("Song Name:");
                        if (fgets(remtmp.name,101,stdin) == NULL) continue;
                        remtmp.name[strcspn(remtmp.name,"\n")] = '\0';
                        printf("Artist Name:");
                        if (fgets(remtmp.artist,101,stdin) == NULL) continue;
                        remtmp.artist[strcspn(remtmp.artist,"\n")] = '\0';

                        Song *rem1 = Find(songlib,&remtmp);
                        if(rem1!=NULL){
                            printf("Song removed.\n");
                            RemoveSong(&songlib,rem1);
                        }
                        else{
                            printf("Song doesn't exist.\n");
                        }
                    }
/*back*/            if(sid==4){
                        printf("Going Back\n");
                        printf("~~~~~~~~~~~~~~~~~~~~~\n");
                        break;
                    }
                }
            }

/*Albums*/  if(ID==2){
                while(1){
                FILE *userinp = fopen("User_History.txt","a");
                printf("\n=======Albums Library========\n");
                FILE *albptr=fopen("Albums.txt","r");
                char temp[201]="";
                Album *List=malloc(sizeof(Album));
                int idx=1;
                printf("ID  Name                    No  \n");
                if (albptr) {
                    while(fgets(temp,201,albptr)!=NULL){
                        if (sscanf(temp,"%d\t%[^\t]\t%d\t%[^\r\n]", &List->id, List->name, &List->songnum, List->albfilename) == 4) {
                            printf("%2d   %-23s %d\n", idx++, List->name, List->songnum);
                        }
                    }
                    fclose(albptr);
                } else {
                    printf("Albums file not found or empty.\n");
                }
                free(List);
                printf("\n============================\n1.Open Album\n2.Add Album\n3.Remove Album\n4.Add Songs to Album\n5.Remove Songs from Album\n6.Back\n============================\n");
                printf("Where to M'lord?:");

                int id = logvalue(userinp);
                if (id == -1) {
                    if (userinp) fclose(userinp);
                    continue;
                }

/*open alb*/    if(id==1){
                    printf("Enter Album ID:");
                    int aid = logvalue(userinp);
                    if (aid == -1) { 
                        if (userinp) fclose(userinp); 
                        continue; 
                    }
                    Album *target=GetAlbID(albumnode,aid);
                    if(target!=NULL){
                        ViewSongsinAlbum(target);
                    } else {
                        printf("Album not found.\n");
                    }
                }
/*add alb*/     if(id==2){
                    Album *new=malloc(sizeof(Album));
                    new->next = NULL;
                    new->songhead = NULL;
                    new->songnum = 0;
                    memset(new->albfilename,0,sizeof(new->albfilename));
                    memset(new->name,0,sizeof(new->name));
                    printf("Album Name:");
                    char albuf[101];
                    if (fgets(albuf, 101, stdin)) {
                        albuf[strcspn(albuf,"\n")] = '\0';
                        if (userinp) userlog(userinp, albuf);
                        strcpy(new->name, albuf);
                    } else {
                        free(new);
                        if (userinp) fclose(userinp);
                        continue;
                    }
                    printf("Album Added.\n");
                    AddAlbum(&albumnode,new);
                }
/*rem alb*/     if(id==3){
                    printf("Enter Album Position (1, 2, 3...):");
                    int aid = logvalue(userinp);
                    if (aid == -1) { if (userinp) fclose(userinp); continue; }

                    Album *rem=GetAlbID(albumnode,aid);
                    if(rem==NULL){
                        printf("Error: Album at position %d not found.\n", aid);
                    }
                    else{
                        printf("Album removed.\n");
                        RemoveAlbum(&albumnode,rem);
                    }
                }
/*addsong alb*/ if(id==4){
                    printf("Which Album do u wanna add songs to:");
                    int aid = logvalue(userinp);
                    if (aid == -1) { if (userinp) fclose(userinp); continue; }
                    Album *tar=GetAlbID(albumnode,aid);
                    if(tar==NULL){
                        printf("Error, try again.\n");
                    }
                    else{
                        printf("Songs available:\n");
                        ViewSongs(&songlib);
                        printf("ID of song to add to album:");
                        int sid = logvalue(userinp);
                        if(sid==-1){
                            printf("Error, try again.\n");
                            if (userinp) fclose(userinp);
                            continue;
                        }
                        Song *tarsong=GetSongID(songlib,sid);
                        if(tarsong==NULL){
                            printf("Error, try again.\n");
                        }
                        else{
                            Song *tarsong2=FindSongAlb(tar,sid);
                            if(tarsong2!=NULL){
                                printf("Song already exists.\n");
                            }
                            else{
                                Song *add=malloc(sizeof(Song));
                                if (!add) { printf("Memory allocation failed.\n"); continue; }
                                add->id=tarsong->id;
                                strcpy(add->name,tarsong->name);
                                strcpy(add->artist,tarsong->artist);
                                add->next = NULL;
                                /* name matches Album.c function name */
                                Addsongtoalbum(tar,add);
                                printf("Added song to %s.\n",tar->name);
                            }
                        }

                    }

}
/*remsong alb*/ if(id==5){
                    printf("Which album do u wanna remove from:");
                    int aid=logvalue(userinp);
                    if (aid == -1) { if (userinp) fclose(userinp); continue; }
                    Album *tar=GetAlbID(albumnode,aid);
                    if(tar==NULL){
                        printf("Error, try again.\n");
                    }
                    else{
                        printf("Songs in the album:\n");
                        ViewSongsinAlbum(tar);
                        printf("ID of song to remove from album:");
                        int sid = logvalue(userinp);
                        if(sid==-1){
                            printf("Error, try again.\n");
                            if (userinp) fclose(userinp);
                            continue;
                        }
                        Song *tarsong=GetSongID(songlib,sid);
                        if(tarsong==NULL){
                            printf("Error, try again.\n");
                        }
                        else{
                            Song *tarsong2=FindSongAlb(tar,sid);
                            if(tarsong2==NULL){
                                printf("Song doesn't exist in album.\n");
                            }
                            else{
                                Song *rem = tarsong2;
                                RemsongfromAlbum(tar,rem);
                                printf("Removed song from %s.\n",tar->name);
                            }
                        }
                    }
}
/*back*/        if(id==6){
                    if (userinp) fclose(userinp);
                    break;
                }
                if (userinp) fclose(userinp);
                }
            }

/*Playlist*/if(ID==3){
                while(1){
                    FILE *userinp = fopen("User_History.txt","a");
                    printf("\n=======Playlist Menu========\n");
                    printf("1.View Playlist\n2.Add Song to Playlist\n3.Remove Song from Playlist\n4.Add Album to Playlist\n5.Remove Album from Playlist\n6.Back\n============================\n");
                    printf("Order me Sire:");

                    int id = logvalue(userinp);
                    if (id == -1) {
                        if (userinp) fclose(userinp);
                        continue;
                    }

/*view play*/       if(id==1){
                        ViewPlaylist(&playlisthead);
                    }
/*add song*/        if(id==2){
                        printf("\nSongs available to add:\n");
                        /* FIX: pass pointer to head */
                        ViewSongs(&songlib);
                        printf("ID of song to add to playlist:");
                        int sid = logvalue(userinp);
                        if(sid==-1){
                            printf("Error, try again.\n");
                            if (userinp) fclose(userinp);
                            continue;
                        }

                        Song *tarsong = GetSongID(songlib, sid);
                        if(tarsong==NULL){
                            printf("Error: Song not found at position %d.\n", sid);
                        }
                        else{
                            Playnode *new_node = malloc(sizeof(Playnode));
                            if (!new_node) { printf("Memory allocation failed.\n"); continue; }
                            
                            new_node->newsong = malloc(sizeof(Song));
                            if (!new_node->newsong) { free(new_node); printf("Memory allocation failed.\n"); continue; }

                            new_node->newsong->id = tarsong->id;
                            strcpy(new_node->newsong->name, tarsong->name);
                            strcpy(new_node->newsong->artist, tarsong->artist);
                            
                            AddsongtoPlaylist(&playlisthead, new_node);
                            printf("Added '%s' to playlist.\n", new_node->newsong->name);
                        }
                    }
/*rem song*/        if(id==3){
                        if(playlisthead==NULL){
                            printf("Playlist is empty. Nothing to remove.\n");
                        }
                        else{
                            ViewPlaylist(&playlisthead);
                            printf("Enter Position (ID) of song to remove:");
                            int sid = logvalue(userinp);
                            if(sid==-1){
                                printf("Error, try again.\n");
                                if (userinp) fclose(userinp);
                                continue;
                            }
                            
                            Playnode *target = playlisthead;
                            int cnt = 1;
                            do {
                                if (cnt == sid) {
                                    RemsongfromPlaylist(&playlisthead, target);
                                    break;
                                }
                                target = target->next;
                                cnt++;
                            } while(target != playlisthead);

                            if(cnt != sid){
                                printf("Error: Song not found at position %d.\n", sid);
                            }
                        }
                    }
/*add album*/       if(id==4){
                        printf("\nEnter Album Position (1, 2, 3...) to add:");
                        int aid = logvalue(userinp);
                        if (aid == -1) { if (userinp) fclose(userinp); continue; }
                        
                        Album *target_alb = GetAlbID(albumnode, aid);
                        if(target_alb==NULL){
                            printf("Error: Album at position %d not found.\n", aid);
                        } else {
                            Addalbtoplaylist(&playlisthead, target_alb);
                        }
                    }
/*rem album*/       if(id==5){
                        printf("\nEnter Album Position (1, 2, 3...) to remove:");
                        int aid = logvalue(userinp);
                        if (aid == -1) { if (userinp) fclose(userinp); continue; }
                        
                        Album *target_alb = GetAlbID(albumnode, aid);
                        if(target_alb==NULL){
                            printf("Error: Album at position %d not found.\n", aid);
                        } else {
                            Remalbfromplaylist(&playlisthead, target_alb);
                        }
                    }
/*back*/            if(id==6){
                        if (userinp) fclose(userinp);
                        break;
                    }

                    if (userinp) fclose(userinp);
                }
            }

/*history*/ if(ID==4){
                FILE *htry;
                htry=fopen("User_History.txt","r");
                if (htry) {
                    char log_line[256];
                    printf("\n--- USER COMMAND HISTORY ---\n");
                    while(fgets(log_line,256,htry)!=NULL){
                        printf("%s",log_line);
                    }
                    printf("---------------------------\n");
                    fclose(htry);
                } else {
                    printf("User history file not found.\n");
                }
            }

/*exit*/    if(ID==5){
                FILE *userinp = fopen("User_History.txt","a");
                printf("Leaving already? :(\n1.Yes\n2.No\n");
                int id = logvalue(userinp);
                if (id == 1){
                    if (userinp) fclose(userinp);
                    printf("Ara Ara Sayonara~\n");
                    return 0;
                }
                if (userinp) fclose(userinp);
            }
    }
}
