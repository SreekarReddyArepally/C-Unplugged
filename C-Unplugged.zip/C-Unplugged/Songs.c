#include "Songs.h"
#include "Album.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

extern int SONGID;

void ViewSongs(Song **head){
    Song *temp = *head;
    if (temp == NULL) {
        printf("The Song Library is empty.\n");
        return;
    }
    int idx = 1;
    printf("=============================================================================\n");
    printf("ID   Name                                        Artist\n");
    while(temp != NULL){
        printf("%2d   %-43s %s\n", idx++, temp->name, temp->artist);
        temp = temp->next;
    }
    printf("=============================================================================\n");
}

Song *FindSongAlb(Album *target,int idx){
    if (!target) return NULL;
    Song *cur = target->songhead;
    while(cur){
        if(cur->id == idx) return cur;
        cur = cur->next;
    }
    return NULL;
}

Song *GetSongID(Song *head,int idx){
    Song *temp=head;
    int cnt=1;
    while(temp!=NULL){
        if(cnt==idx){
            return temp;
        }
        temp=temp->next;
        cnt++;
    }
    return NULL;
}

void insert(const char *filename,Song **head){
    FILE *songptr = fopen(filename,"r");
    if (!songptr) return;
    char temp[201] = "";
    while(fgets(temp,201,songptr) != NULL){
        Song *newsong = malloc(sizeof(Song));
        if (!newsong) break;
        newsong->next = NULL;
        if (sscanf(temp,"%[^\t]\t%[^\r\n]", newsong->name, newsong->artist) < 2){ 
            free(newsong);
            continue;
        }
        if(*head == NULL){
            *head = newsong;
        } else {
            Song *t = *head;
            while(t->next != NULL) t = t->next;
            t->next = newsong;
        }
        newsong->id = SONGID++;
    }
    fclose(songptr);
}

void RewriteFile(Song **head){
    FILE *songptr = fopen("Songs.txt","w");
    if (!songptr) return;
    Song *temp = *head;
    while(temp != NULL){
        fprintf(songptr,"%s\t%s\n",temp->name,temp->artist);
        temp = temp->next;
    }
    fclose(songptr);
}

Song *Find(Song *head,Song *remsong){
    Song *temp=head;
    while(temp!=NULL){
        if(strcmp(temp->name,remsong->name)==0 && strcmp(temp->artist,remsong->artist)==0){
            return temp;
        }
        temp=temp->next;
    }
    return NULL;
}

void AddSong(Song **head,Song *newsong){
    if (!newsong) return;
    newsong->next = NULL;
    FILE *songptr;
    if(*head==NULL){
        *head=newsong;
    }
    else{
        Song *tempsong = *head;
        while(tempsong->next!=NULL) tempsong=tempsong->next;
        tempsong->next=newsong;
    }
    songptr=fopen("Songs.txt","a");
    if (songptr){
        fprintf(songptr,"%s\t%s\n",newsong->name,newsong->artist);
        fclose(songptr);
    }
    return;
}

void RemoveSong(Song **head,Song *remsong){
    if (!head || !*head || !remsong) return;
    Song *tempsong=*head;
    if(*head==remsong){       /*if first song itself is the removed song*/
        *head=remsong->next;
        RewriteFile(head);
        free(remsong);
        return;
    }
    while(tempsong!=NULL && tempsong->next!=remsong){   /*move till we find song or NULL*/
        tempsong=tempsong->next;
    }
    if(tempsong!=NULL){ /*remsong exists and we remove it*/
        tempsong->next=remsong->next;
        RewriteFile(head);
        free(remsong);
    }
}